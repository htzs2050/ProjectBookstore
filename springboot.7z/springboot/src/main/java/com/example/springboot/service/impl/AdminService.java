package com.example.springboot.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.example.springboot.controller.dto.LoginDTO;
import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.LoginRequest;
import com.example.springboot.entity.Admin;
import com.example.springboot.exception.ServiceException;
import com.example.springboot.mapper.AdminMapper;
import com.example.springboot.service.IAdminService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
@Slf4j
@Service
public class AdminService implements IAdminService{

    private static final String DEFAULT_PASS = "123456";
    private static final String  PASS_SALT  = "SALT";
    @Autowired
    AdminMapper  adminMapper;
    @Override
    public List<Admin> list() {
        return adminMapper.list();
    }

    @Override
    public PageInfo<Admin> page(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(),baseRequest.getPageSize());
        List<Admin> admins = adminMapper.listByCondition(baseRequest);
        new PageInfo<>(admins);
        return new PageInfo<>(admins);
    }

    @Override
    public void save(Admin obj) {
        Date date = new Date();
        obj.setAccountId(DateUtil.format(date, "yyyyMMddHHmmss"));
        if(StrUtil.isBlank(obj.getPassword())){
            obj.setPassword(DEFAULT_PASS);
        }else{
            // obj.setPassword(securePass(obj.getPassword()));//加密模块
        }
        try {
            adminMapper.save(obj);
        } catch (DuplicateKeyException e) {
            log.error("数据插入失败 , username:{}" , obj.getUsername(),e);

            throw new ServiceException("用户名重复");
        }


    }

    @Override
    public Admin getByaccountId(String accountId) {
        return adminMapper.getByaccountId(accountId);
    }

    @Override
    public void update(Admin obj) {
//        obj.setUpdatetime(new Date());
        adminMapper.updateByaccountId(obj);
    }

    @Override
    public void deleteByaccountId(String accountId) {
        adminMapper.deleteByaccountId(accountId);
    }

    @Override
    public LoginDTO login(LoginRequest request) {//登录并返回模块

//       try {
           Admin admin = adminMapper.getByaccountIdAndpassword(request);
           if(admin == null){
               throw  new ServiceException("用户名或密码错误");
           }
           LoginDTO loginDTO = new LoginDTO();
           BeanUtils.copyProperties(admin , loginDTO);
           return loginDTO;
//       }catch (Exception e){
//           log.error("登录异常", e);
//           re

    }
    private  String  securePass(String password){
        return SecureUtil.md5(password + PASS_SALT);
    }
}
