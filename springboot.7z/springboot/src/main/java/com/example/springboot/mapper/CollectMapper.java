package com.example.springboot.mapper;

import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.entity.Collect;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CollectMapper {

    //    @Select("select * from user")
//   List<Collect> list();

    List<Collect>listByCondition(BaseRequest baseRequest);

    void addCollect(Collect obj);

//    User getByphone(Integer phone);

//    Collect getByUid(String Uid);

    void updateByCid(Collect collect);

    void deleteByCid(String cid);

//    List<? extends Collect> listByCondition(BaseRequest baseRequest, String uid);

//    List<Collect> list();

    //  Collect  getByaccountUidAndpassword(LoginRequest request);
}
