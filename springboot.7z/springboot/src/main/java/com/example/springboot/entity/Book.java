package com.example.springboot.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class Book {






        private String id;
        private String name;
        private String description;
        private String publishdate;
        private String publisher;
        private String author;
        private String category;
        private String isbn;
        private float price;
        @JsonFormat(pattern = "yyyy-MM-dd" , timezone = "GMT+8" )
        private LocalDate createtime;
        @JsonFormat(pattern = "yyyy-MM-dd" , timezone = "GMT+8" )
        private LocalDate updatetime;

        /**
         * 图书图片的链接
         */
        private String cover;

        private List<String> categories;


}
