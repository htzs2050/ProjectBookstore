package com.example.springboot.controller;

import com.example.springboot.common.Result;
import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.CollectPageRequest;
import com.example.springboot.entity.Collect;
import com.example.springboot.service.ICollectService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//把 IUserService userService;标注成springboot的一个组件
@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/collect")
public class CollectController {


    private static final String BASE_FILE_PATH = System.getProperty("user.dir") + "/files/";

    @Autowired
    ICollectService collectService;

//    @PostMapping("/login")
//    public Result login(@RequestBody LoginRequest request){
//       // request.setPassword(securePass(request.getPassword()));//可理解为解码模块
//        LoginDTO login = collectService.login(request);
//        if(login == null){
//            return Result.error("用户名或密码错误");
//        }
//        return Result.success(login);
//    }

//   @GetMapping("/list")
//    public Result list(){
//       List<Collect> list = collectService.list();
//        return Result.success(list);
//
//    }

    @GetMapping("/page")
    public Result getByUid(CollectPageRequest pageRequest){

        return Result.success(collectService.getByUid(pageRequest));

    }
    @PostMapping("/save")
    public Result addCollect(@RequestBody Collect obj){

        collectService.addCollect(obj);
        return Result.success();//内部不返回任何值，data是null
    }
//    @GetMapping("/{uid}")
//    public Result getByUid(@PathVariable String Uid){
//        Collect obj = collectService.getByUid(Uid);
//        return Result.success(obj);
//
//    }

    @PutMapping("/update")
    public Result updateById(@RequestBody Collect obj){
        collectService.updateByCid(obj);
        return Result.success();//内部不返回任何值，data是null
    }
    @DeleteMapping("/delete/{cid}")
    public Result delete(@PathVariable String cid){
        collectService.deleteByCid(cid);
        return Result.success();

    }

}
//以JSON返回数据

