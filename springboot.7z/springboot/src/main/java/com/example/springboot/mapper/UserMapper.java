package com.example.springboot.mapper;

import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.UserPageRequest;
import com.example.springboot.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;


import java.util.List;

@Mapper
public interface UserMapper {

//    @Select("select * from user")
    List<User> list();

    List<User>listByCondition(BaseRequest baseRequest);

    void save(User user);

//    User getByphone(Integer phone);

    User getByaccountId(String accountId);

    void updateByaccountId(User user);

    void deleteByaccountId(String accountId);
}


