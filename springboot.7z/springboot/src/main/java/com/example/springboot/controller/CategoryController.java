package com.example.springboot.controller;

import cn.hutool.core.collection.CollUtil;
import com.example.springboot.common.Result;
import com.example.springboot.controller.dto.LoginDTO;
import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.CategoryPageRequest;
import com.example.springboot.controller.request.LoginRequest;
import com.example.springboot.entity.Category;
import com.example.springboot.service.ICategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

//把 IUserService userService;标注成springboot的一个组件
@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/category")
public class CategoryController {


    @Autowired
    ICategoryService categoryService;

//    @PostMapping("/login")
//    public Result login(@RequestBody LoginRequest request){
//       // request.setPassword(securePass(request.getPassword()));//可理解为解码模块
//        LoginDTO login = categoryService.login(request);
//        if(login == null){
//            return Result.error("用户名或密码错误");
//        }
//        return Result.success(login);
//    }

//   @GetMapping("/list")
//    public Result list(){
//       List<Category> list = categoryService.list();
//        return Result.success(list);
//
//    }

    @GetMapping("/page")
    public Result page(CategoryPageRequest pageRequest){

        return Result.success(categoryService.page(pageRequest));

    }
    @GetMapping("/tree")
    public Result tree() {
        List<Category> list = categoryService.list();


        return Result.success(createTree(null, list));
    }
    private List<Category> createTree(String pid, List<Category> categories) {
        List<Category> treeList = new ArrayList<>();
        for (Category category : categories) {
            if (pid == null) {
                if (category.getPid() == null) {  // 那这就是第一级节点
                    treeList.add(category);
                    category.setChildren(createTree(category.getId(), categories));
                }
            } else {
                if (pid.equals(category.getPid())) {
                    treeList.add(category);
                    category.setChildren(createTree(category.getId(), categories));
                }
            }
            if (CollUtil.isEmpty(category.getChildren())) {
                category.setChildren(null);
            }
        }
        return treeList;
    }
    @PostMapping("/save")
    public Result save(@RequestBody Category obj){

        categoryService.save(obj);
        return Result.success();//内部不返回任何值，data是null
    }
    @GetMapping("/{id}")
    public Result getById(@PathVariable String id){
        Category obj = categoryService.getById(id);
        return Result.success(obj);

    }
    @PutMapping("/update")
    public Result updateById(@RequestBody Category obj){
        categoryService.updateById(obj);
        return Result.success();//内部不返回任何值，data是null
    }
    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable String id){
        categoryService.deleteById(id);
        return Result.success();

    }



}
//以JSON返回数据

