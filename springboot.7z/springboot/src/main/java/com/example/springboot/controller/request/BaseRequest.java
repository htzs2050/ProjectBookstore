package com.example.springboot.controller.request;

import lombok.Data;

@Data
public class BaseRequest{
    private Integer pageNum = 1;//表示分页默认为1
    private Integer pageSize = 10;//表示分页默认每页有10个元素

}
