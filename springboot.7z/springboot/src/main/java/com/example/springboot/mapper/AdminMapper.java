package com.example.springboot.mapper;

import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.LoginRequest;
import com.example.springboot.controller.request.UserPageRequest;
import com.example.springboot.entity.Admin;
import com.example.springboot.entity.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface AdminMapper {

//    @Select("select * from user")
    List<Admin> list();

    List<Admin>listByCondition(BaseRequest baseRequest);

    void save(Admin obj);

//    User getByphone(Integer phone);

    Admin getByaccountId(String accountId);

    void updateByaccountId(Admin admin);

    void deleteByaccountId(String accountId);

    Admin  getByaccountIdAndpassword(LoginRequest request);
}


