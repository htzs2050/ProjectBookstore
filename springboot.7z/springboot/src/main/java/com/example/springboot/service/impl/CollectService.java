package com.example.springboot.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.CollectPageRequest;
import com.example.springboot.entity.Admin;
import com.example.springboot.entity.Collect;
import com.example.springboot.mapper.CollectMapper;
import com.example.springboot.service.ICollectService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class CollectService implements ICollectService {
    @Resource
    CollectMapper collectMapper;
//    @Override
//    public List<collect> list() {
//        return collectMapper.list();
//    }



    @Override
    public PageInfo<Collect> getByUid(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(),baseRequest.getPageSize());


        return new PageInfo<>(collectMapper.listByCondition(baseRequest));
    }

//    @Override
//    public void save(Collect obj) {
//        Date date = new Date();
//        obj.setId(DateUtil.format(date, "yyyyMMddHHmmss"));
//
//        collectMapper.save(obj);
//    }
    @Override
    public void addCollect(Collect obj) {
        Date date = new Date();
        obj.setCid(DateUtil.format(date, "yyyyMMddHHmmss"));
       // obj.setCategory(category(obj.getCategories()));
        collectMapper.addCollect(obj);
    }

//    @Override
//    public Collect getByUid(String uid) {
//        return collectMapper.getByUid(uid);
//    }




    @Override
    public void updateByCid(Collect obj) {
        //obj.setCategory(category(obj.getCategories()));
        collectMapper.updateByCid(obj);
    }

    @Override
    public void deleteByCid(String cid) {
        collectMapper.deleteByCid(cid);
    }
//    private String category(List<String> categories) {
//        StringBuilder sb = new StringBuilder();
//        if (CollUtil.isNotEmpty(categories)) {
//            categories.forEach(v -> sb.append(v).append(" > "));
//            return sb.substring(0, sb.lastIndexOf(" > "));
//        }
//        return sb.toString();
//    }
//    @Override
//    public LoginDTO login(LoginRequest request) {
//        return null;
//    }
}
