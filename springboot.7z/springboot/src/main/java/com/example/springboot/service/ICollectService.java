package com.example.springboot.service;

import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.CollectPageRequest;
import com.example.springboot.entity.Collect;
import com.github.pagehelper.PageInfo;

public interface ICollectService {
//    List<Collect> list();

    PageInfo<Collect> getByUid(BaseRequest baseRequest);

    void addCollect(Collect obj);

//    Collect getByUid(String uid);


    void updateByCid(Collect obj);


    void deleteByCid(String uid);

//    LoginDTO login(LoginRequest request);
}
