package com.example.springboot.service.impl;

import cn.hutool.core.date.DateUtil;
import com.example.springboot.controller.dto.LoginDTO;
import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.LoginRequest;

import com.example.springboot.entity.Category;
import com.example.springboot.mapper.CategoryMapper;
import com.example.springboot.service.ICategoryService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class CategoryService implements ICategoryService {
    @Resource
    CategoryMapper categoryMapper;
    @Override
    public List<Category> list() {
        return categoryMapper.list();
    }



    @Override
    public PageInfo<Category> page(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(),baseRequest.getPageSize());
//        List<Category> categories =
//        new PageInfo<>(categories);
        return new PageInfo<>(categoryMapper.listByCondition(baseRequest));
    }

    @Override
    public void save(Category obj) {
        Date date = new Date();
        obj.setId(DateUtil.format(date, "yyyyMMddHHmmss"));

        categoryMapper.save(obj);
    }

    @Override
    public Category getById(String id) {
        return categoryMapper.getById(id);
    }

    @Override
    public void updateById(Category obj) {
        categoryMapper.updateById(obj);
    }

    @Override
    public void deleteById(String id) {
        categoryMapper.deleteById(id);
    }

//    @Override
//    public LoginDTO login(LoginRequest request) {
//        return null;
//    }
}
