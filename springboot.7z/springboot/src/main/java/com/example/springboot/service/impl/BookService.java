package com.example.springboot.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.entity.Book;
import com.example.springboot.exception.ServiceException;
import com.example.springboot.mapper.BookMapper;
import com.example.springboot.service.IBookService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class BookService implements IBookService {
    @Resource
    BookMapper bookMapper;
//    @Override
//    public List<Book> list() {
//        return bookMapper.list();
//    }



    @Override
    public PageInfo<Book> page(BaseRequest baseRequest) {
        PageHelper.startPage(baseRequest.getPageNum(),baseRequest.getPageSize());

        return new PageInfo<>(bookMapper.listByCondition(baseRequest));
    }

//    @Override
//    public void save(Book obj) {
//        Date date = new Date();
//        obj.setId(DateUtil.format(date, "yyyyMMddHHmmss"));
//
//        bookMapper.save(obj);
//    }
    @Override
    public void save(Book obj) {
        Date date = new Date();
        obj.setId(DateUtil.format(date, "yyyyMMddHHmmss"));
        obj.setCategory(category(obj.getCategories()));
        bookMapper.save(obj);
        }

    @Override
    public Book getById(String id) {
        return bookMapper.getById(id);
    }

    @Override
    public void updateById(Book obj) {
        obj.setCategory(category(obj.getCategories()));
        bookMapper.updateById(obj);
    }

    @Override
    public void deleteById(String id) {
        bookMapper.deleteById(id);
    }
    private String category(List<String> categories) {
        StringBuilder sb = new StringBuilder();
        if (CollUtil.isNotEmpty(categories)) {
            categories.forEach(v -> sb.append(v).append(" > "));
            return sb.substring(0, sb.lastIndexOf(" > "));
        }
        return sb.toString();
    }
//    @Override
//    public LoginDTO login(LoginRequest request) {
//        return null;
//    }
}
