package com.example.springboot.controller;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.StrUtil;
import com.example.springboot.common.Result;
import com.example.springboot.controller.request.BookPageRequest;
import com.example.springboot.entity.Admin;
import com.example.springboot.entity.Book;
import com.example.springboot.service.IBookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

//把 IUserService userService;标注成springboot的一个组件
@Slf4j
@CrossOrigin
@RestController
@RequestMapping("/book")
public class BookController {


    private static final String BASE_FILE_PATH = System.getProperty("user.dir") + "/files/";

    @Autowired
    IBookService bookService;

//    @PostMapping("/login")
//    public Result login(@RequestBody LoginRequest request){
//       // request.setPassword(securePass(request.getPassword()));//可理解为解码模块
//        LoginDTO login = bookService.login(request);
//        if(login == null){
//            return Result.error("用户名或密码错误");
//        }
//        return Result.success(login);
//    }

//   @GetMapping("/list")
//    public Result list(){
//       List<Book> list = bookService.list();
//        return Result.success(list);
//
//    }

    @GetMapping("/page")
    public Result page(BookPageRequest pageRequest){

        return Result.success(bookService.page(pageRequest));

    }
    @PostMapping("/save")
    public Result save(@RequestBody Book obj){

        bookService.save(obj);
        return Result.success();//内部不返回任何值，data是null
    }
    @GetMapping("/{id}")
    public Result getById(@PathVariable String id){
        Book obj = bookService.getById(id);
        return Result.success(obj);

    }
    @PutMapping("/update")
    public Result updateById(@RequestBody Book obj){
        bookService.updateById(obj);
        return Result.success();//内部不返回任何值，data是null
    }
    @DeleteMapping("/delete/{id}")
    public Result delete(@PathVariable String id){
        bookService.deleteById(id);
        return Result.success();

    }

}
//以JSON返回数据

