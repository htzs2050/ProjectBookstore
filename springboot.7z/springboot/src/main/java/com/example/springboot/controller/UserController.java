package com.example.springboot.controller;

import com.example.springboot.common.Result;
import com.example.springboot.controller.request.UserPageRequest;
import com.example.springboot.entity.User;
import com.example.springboot.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.*;

import java.util.List;
//把 IUserService userService;标注成springboot的一个组件
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {


    @Autowired
    IUserService userService;


   @GetMapping("/list")
    public Result list(){
       List<User> users = userService.list();
        return Result.success(users);

    }

    @GetMapping("/page")
    public Result page(UserPageRequest userPageRequest){

        return Result.success(userService.page(userPageRequest));

    }
    @PostMapping("/save")
    public Result save(@RequestBody User user){
        userService.save(user);
        return Result.success();//内部不返回任何值，data是null
    }
    @GetMapping("/{accountId}")
    public Result getByaccountId(@PathVariable String accountId){
        User user = userService.getByaccountId(accountId);
        return Result.success(user);

    }
    @PutMapping("/update")
    public Result update(@RequestBody User user){
        userService.update(user);
        return Result.success();//内部不返回任何值，data是null
    }
    @DeleteMapping("/delete/{accountId}")
    public Result delete(@PathVariable String accountId){
        userService.deleteByaccountId(accountId);
        return Result.success();

    }



}
//以JSON返回数据

