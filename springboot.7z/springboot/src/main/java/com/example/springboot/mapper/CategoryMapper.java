package com.example.springboot.mapper;

import com.example.springboot.controller.request.BaseRequest;
import com.example.springboot.controller.request.LoginRequest;
import com.example.springboot.controller.request.UserPageRequest;
import com.example.springboot.entity.Category;
import com.example.springboot.entity.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CategoryMapper {

    //    @Select("select * from user")
   List<Category> list();

    List<Category>listByCondition(BaseRequest baseRequest);

    void save(Category obj);

//    User getByphone(Integer phone);

    Category getById(String id);

    void updateById(Category category);

    void deleteById(String id);

  //  Category  getByaccountIdAndpassword(LoginRequest request);
}
