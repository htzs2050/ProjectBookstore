package com.example.springboot.controller.request;

import lombok.Data;

@Data
public class CollectPageRequest extends BaseRequest{

    private String uid;

    private String bid;


}
