package com.example.springboot.exception;

public class ServiceException extends  RuntimeException{//用ServiceException继承RuntimeException的原因是如果直接使用RE会导致混淆
    public ServiceException(String message) {
        super(message);
    }
}
