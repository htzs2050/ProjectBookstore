package com.example.springboot.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
public class Category {
    private String id;
    private String name;
    private String remark;
    private String pid;
    @JsonFormat(pattern = "yyyy-MM-dd" , timezone = "GMT+8" )
    private LocalDate createtime;
    @JsonFormat(pattern = "yyyy-MM-dd" , timezone = "GMT+8" )
    private LocalDate updatetime;
    private List<Category> children;
}
